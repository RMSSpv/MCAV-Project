clear all;
%pkg load control

%initPlots;

g = (393/1025)*9.8;
mL=360*(1025/170); %360kg é a masssa do Lander de outra missão e 170kg do Rover, decidi manter a proporção
mR=1025;
m=mR+mL;


Cd=1.05;
rho = 0.015;
%%%%%%%
A1=diag([13.08; 7.62;12.84]);
beta1 = Cd*rho*A1/2;
%%%%%%%
A4=diag([13.08; 7.62;12.84]);
beta4 = Cd*rho*A4/2;


CML=[1.35; 3; -2.74];
CMR=[1.35; 3; -1.1];
CM = mass_center(mL, CML, mR, CMR, m);

[Jx1, Jy1, Jz1] = moment_inertia(CM, mL, CML, mR, CMR);
%J = diag([ Jx , Jy , Jz ]);
[Jx4, Jy4, Jz4] = moment_inertia(CML, mL, CML, 0, [0;0;0]);

Dt = 0.01;
t = 0:Dt:50;
N = length( t );

[r1x1,r1y1,r1z1,r2x1,r2y1,r2z1,r3x1,r3y1,r3z1,r4x1,r4y1,r4z1]=rockets_relative_position(CM);
[r1x4,r1y4,r1z4,r2x4,r2y4,r2z4,r3x4,r3y4,r3z4,r4x4,r4y4,r4z4]=rockets_relative_position(CML);

%pontos de equilibrio
vx1 = 0 ;
vy1 = 0 ;
vz1 = 89 ;%eq1
%vz = 0.000001 ; %eq2
fi1 = 0 ;
theta1 = 0 ;
psi1 = 0 ;
%px = 0 ;
%py = 0 ;
%pz = - 2100 ; %e1
%pz = - 21.3 ; %eq2
wx1 =0 ;
wy1 =0 ;
wz1 = 0 ;

%pontos de equilibrio 2
vx2 = 0 ;
vy2 = 0 ;
vz2 = 45 ;%eq1
%vz = 0.000001 ; %eq2
fi2 = 0 ;
theta2 = 0 ;
psi2 = 0 ;
%px = 0 ;
%py = 0 ;
%pz = - 2100 ; %e1
%pz = - 21.3 ; %eq2
wx2 =0 ;
wy2 =0 ;
wz2 = 0 ;


%pontos de equilibrio 3
vx3 = 0 ;
vy3 = 0 ;
vz3 = 0.000001 ; 
fi3 = 0 ;
theta3 = 0 ;
psi3 = 0 ;
%px = 0 ;
%py = 0 ;
%pz = - 2100 ; %e1
%pz = - 21.3 ; %eq2
wx3 =0 ;
wy3 =0 ;
wz3 = 0 ;

%pontos de equilibrio 4
vx4 = 13.141194224153149200753927221415;
vy4 = 17.213148450021798431852787227163;
vz4 = 0.52987196329849108931620307088184;
%vz = 0.000001 ; %eq2
fi4 = +pi/(180*8) ;
theta4 = -pi/(180*8) ;
psi4 = 0 ;
%px = 0 ;
%py = 0 ;
%pz = - 2100 ; %e1
%pz = - 21.3 ; %eq2
wx4 =0 ;
wy4 =0 ;
wz4 = 0 ;


vx0 = 0 ;
vy0 = 0 ;
vz0 = 89 ;
fi0 = 0 ;
theta0 = 0 ;
psi0 = 0 ;
px0 = 0 ;
py0 = 0 ;
pz0 = - 2100 ;
wx0 =0 ;
wy0 =0 ;
wz0 = 0 ;
x01 = [px0 ; py0 ; pz0 ; fi0; theta0 ; psi0 ; vx0 ; vy0 ; vz0 ; wx0 ; wy0 ; wz0 ];
x02 = [px0 ; py0 ; -250 ; fi0; theta0 ; psi0 ; vx0 ; vy0 ; vz0/2 ; wx0 ; wy0 ; wz0 ];
x03 = [px0 ; py0 ; -21.3 ; fi0; theta0 ; psi0 ; vx0 ; vy0 ; 0 ; wx0 ; wy0 ; wz0 ];
x04 = [px0 ; py0 ; -21.3 ; +pi/(180*8); -pi/(180*8) ; psi0 ; vx4 ; vy4; vz4; wx0 ; wy0 ; wz0 ];


ang = 20*pi/180 ;

%inputs de controlo de equilibrio para simular sistema em malha aberta
u1 = u_eq123(vz1, ang, m, g, beta1, t);
u2 = u_eq123(vz2, ang, m, g, beta1, t);
u3 = u_eq123(vz3, ang, m, g, beta1, t);

T1_4 = 2169.8506516070420965816259713967;
T2_4 = T1_4;
T3_4 = T1_4;
T4_4 = T1_4;
T1u_4 = (t>=0)*T1_4;
T2u_4 = (t>=0)*T2_4;
T3u_4 = (t>=0)*T3_4;
T4u_4 = (t>=0)*T4_4;
u4=[T1u_4;T2u_4;T3u_4;T4u_4];


%SS
[A_1, B_1, C_1, D_1] = SS_matrices(m, Jx1, Jy1, Jz1, beta1, g, ang, fi1, theta1, psi1, vx1, vy1, vz1, wx1, wy1, wz1, r1x1, r1y1, r1z1, r2x1, r2y1, r2z1, r3x1, r3y1, r3z1, r4x1, r4y1, r4z1);
Gl1 = SS_analysis(A_1, B_1, C_1, D_1, u1, t, x01, 1);

[A_2, B_2, C_2, D_2] = SS_matrices(m, Jx1, Jy1, Jz1, beta1, g, ang, fi2, theta2, psi2, vx2, vy2, vz2, wx2, wy2, wz2, r1x1, r1y1, r1z1, r2x1, r2y1, r2z1, r3x1, r3y1, r3z1, r4x1, r4y1, r4z1);
Gl2 = SS_analysis(A_2, B_2, C_2, D_2, u2, t, x02, 2);

[A_3, B_3, C_3, D_3] = SS_matrices(m, Jx1, Jy1, Jz1, beta1, g, ang, fi3, theta3, psi3, vx3, vy3, vz3, wx3, wy3, wz3, r1x1, r1y1, r1z1, r2x1, r2y1, r2z1, r3x1, r3y1, r3z1, r4x1, r4y1, r4z1);
Gl3 = SS_analysis(A_3, B_3, C_3, D_3, u3, t, x03, 3);

[A_4, B_4, C_4, D_4] = SS_matrices(mL, Jx4, Jy4, Jz4, beta4, g, ang, fi4, theta4, psi4, vx4, vy4, vz4, wx4, wy4, wz4, r1x4, r1y4, r1z4, r2x4, r2y4, r2z4, r3x4, r3y4, r3z4, r4x4, r4y4, r4z4);
Gl4 = SS_analysis(A_4, B_4, C_4, D_4, u4, t, x04,4);

%Q = diag([9999,9999,1/(2000*2000), 999999,9999999,999999, 9999999,9999999, 1/(89*89), 999999,999999,999999]);
%R = diag([1/(4*m*g*m*g), 1/(4*m*g*m*g), 1/(4*m*g*m*g), 1/(4*m*g*m*g)]);

%Q = diag([0,0,1, 0,0,0, 0,0, 1/50, 0,0,0]);
%R = diag([1/(4*m*g*m*g), 1/(4*m*g*m*g), 1/(4*m*g*m*g), 1/(4*m*g*m*g)]);

%Q = eye(12);
%R = eye(4);
%R=zeros(4,4);
Q = blkdiag(9*eye(3),0.01*eye(3), 10*eye(3),0.001*eye(3));
R = 0.1*eye(4);


[Kinf,CLinf,gammainf,info_inf, P] = SS_CL_matrices(A_1, B_1, C_1, D_1, Q, R, Gl1);

%[Kinf,CLinf,gammainf,info_inf] = hinfsyn(P,nmeas,ncont);
poles_CLinf = pole(CLinf);
if any(real(poles_CLinf) >= 0), disp('CL system with Hinf controller not stable'); else, disp('CL system with Hinf controller is stable'); end

% select controller:
% i_ctr = 1; % Loop-shaping controller
% i_ctr = 2; % LQR controller
% i_ctr = 3; % H2 controller
i_ctr = 4; % Hinf controller

% simulate controlled system
Dt = 0.01;
t = 0:Dt:50;
r = [0;0;-500;0;0;0;0;0;0;0;0;0]*(t>=0);
NSim = length(t);
nx = 12;
nu = 4;
x = zeros(nx,NSim);
xu = zeros(nx,NSim);
u = zeros(4,NSim);
x(:,1) = [0;0;-2100;0;0;0;0;0;89;0;0;0];
C=eye(12);   
for k = 1:NSim
    %r(:,k+1) = r(:,k)./2
    %r(:,k+1) = r(:,k)./2
    % get measurements:
    y(:,k) = C*x(:,k);

    % get control action:
    switch i_ctr
        case 1 % simple controller:
            u(:,k) = -Klqr*[(y(:,k) - r(:,k));x(2:nx,k)]; % Basic LQR controller (for reference tracking)
        
        case 2 % loop shaping controller (with dynamics):
            u_dot = -(k0/a*C*B + 1)*b*u(:,k) - k0*b/a*C*(A + eye(nx))*x(:,k) + k0*b/a*r(:,k);
            up = u(:,k) + Dt*u_dot; % integrate control state
            if k < NSim
                u(:,k+1) = up;
            end

        case 3 % H2 controller
            v = -[(r(:,k)-y(:,k));-x(2:nx,k)];
            u(:,k) = K2.C*v; % approximation for LQR-like performance of H2

        case 4 % Hinf controller
            v = -[(r(:,k)-y(:,k))];
            u(:,k) = Kinf.C*v; % approximation for LQR-like performance of Hinf

        otherwise % step input (no control)
            u(:,k) = r(:,k);
    end

    % simulate system:
    x_dot = A_1*x(:,k) + B_1*u(:,k); % system derivatives
    xp = x(:,k) + Dt*x_dot; % integrate system state
    if k < NSim
        x(:,k+1) = xp;
    end

end

figure(1002);
plot(t,u);
grid on;
xlabel('$$t [s]$$');
ylabel('$$u(t)$$');
legend('$$u_1$$','$$u_2$$','$$u_3$$','$$u_4$$');

figure(1003);
plot(t,y(3,:),t,r(3,:));
grid on;
xlabel('$$t [s]$$');
legend('$$pz$$','$$r_pz$$');

figure(1004);
plot(t,y(9,:),t,r(9,:));
grid on;
xlabel('$$t [s]$$');
legend('$$vz$$','$$r_vz$$');


%State machine
Q1 = blkdiag(0.5*eye(3),0.01*eye(3), 80*eye(3),0.001*eye(3));
R1 = 0.1*eye(4);
[Kinf1,CLinf1,gammainf1,info_inf1, P1] = SS_CL_matrices(A_1, B_1, C_1, D_1, Q1, R1, Gl1);


Q2 = blkdiag(5*eye(3),0.01*eye(3), 70*eye(3),0.001*eye(3));
R2 = 0.1*eye(4);
[Kinf2,CLinf2,gammainf2,info_inf2, P2] = SS_CL_matrices(A_2, B_2, C_2, D_2, Q2, R2, Gl2);


Q3 = blkdiag(9*eye(3),0.01*eye(3), 90*eye(3),0.001*eye(3));
R3 = 0.1*eye(4);
[Kinf3,CLinf3,gammainf3,info_inf3, P3] = SS_CL_matrices(A_3, B_3, C_3, D_3, Q3, R3, Gl3);


Q4 = blkdiag(9*eye(3),0.01*eye(3), 80*eye(3),0.001*eye(3));
R4 = 0.1*eye(4);
[Kinf4,CLinf4,gammainf4,info_inf4, P4] = SS_CL_matrices(A_4, B_4, C_4, D_4, Q4, R4, Gl4);

% select controller:
% i_ctr = 1; % Loop-shaping controller
% i_ctr = 2; % LQR controller
% i_ctr = 3; % H2 controller
i_ctr = 4; % Hinf controller

% simulate controlled system
Dt = 0.01;
t = 0:Dt:300;
r = [0;0;-2100;0;0;0;0;0;60;0;0;0]*(t>=0);
ind=-1;

NSim = length(t);
nx = 12;
nu = 4;
x = zeros(nx,NSim);
xu = zeros(nx,NSim);
u = zeros(4,NSim);
x(:,1) = [0;0;-2100;0;0;0;0;0;89;0;0;0];
C=eye(12);   

Kinf = Kinf1;
A=A_1;
B=B_1;

for k = 1:NSim
    %r(:,k+1) = r(:,k)./2
    %r(:,k+1) = r(:,k)./2
    % get measurements:
    y(:,k) = C*x(:,k);

    % get control action:
    switch i_ctr
        case 1 % simple controller:
            u(:,k) = -Klqr*[(y(:,k) - r(:,k));x(2:nx,k)]; % Basic LQR controller (for reference tracking)
        
        case 2 % loop shaping controller (with dynamics):
            u_dot = -(k0/a*C*B + 1)*b*u(:,k) - k0*b/a*C*(A + eye(nx))*x(:,k) + k0*b/a*r(:,k);
            up = u(:,k) + Dt*u_dot; % integrate control state
            if k < NSim
                u(:,k+1) = up;
            end

        case 3 % H2 controller
            v = -[(r(:,k)-y(:,k));-x(2:nx,k)];
            u(:,k) = K2.C*v; % approximation for LQR-like performance of H2

        case 4 % Hinf controller
            v = -[(r(:,k)-y(:,k))];
            u(:,k) = Kinf.C*v; % approximation for LQR-like performance of Hinf

        otherwise % step input (no control)
            u(:,k) = r(:,k);
    end

    % simulate system:
    x_dot = A*x(:,k) + B*u(:,k); % system derivatives
    xp = x(:,k) + Dt*x_dot; % integrate system state
    
    if xp(9) > 70
        r(3,k+1) = (4000/4001)*r(3,k);
        r(9,k+1) = (5000/5001)*r(9,k);
    end
    if xp(9) < 70
        
        Kinf=Kinf2;
        A=A_2;
        B=B_2;
        r(3,k+1) = (4000/4001)*r(3,k);
        r(9,k+1) = (5000/5001)*r(9,k);
        %r(:,k) = [0;0;-500;0;0;0;0;0;0;0;0;0]*(t(k)>=0);
        if xp(3)< -35 &&  xp(9) < 5
            Kinf=Kinf3;
            A=A_3;
            B=B_3;
            r(:,k) = [0;0;-21.3;0;0;0;0;0;0;0;0;0]*(t(k)>=0);

            if xp(3)< -30 &&  xp(9) < 2
               ind=ind + 1;
                Kinf=Kinf4;
                A=A_4;
                B=B_4;
                
                ref4_py = xp(8)*Dt*ind;
                ref4_px = xp(9)*Dt*ind;

                r(:,k) = [ref4_px;ref4_py;-21.3;fi4;theta4;psi4;vx4;vy4;vz4;0;0;0]*(t(k)>=0);
                
                if xp(1) > 50 || xp(2) > 50 
                    %disp('Tudo Pacas')
                    Kinf=Kinf3;
                    A=A_3;
                    B=B_3;
                    r(:,k) = [0;0;0;0;0;0;0;0;0;0;0;0]*(t(k)>=0);
                end
            end
        end
    end
    
 
    if k < NSim
        x(:,k+1) = xp;
    end
end

figure(9041002);
plot(t,u);
grid on;
xlabel('$$t [s]$$');
ylabel('$$u(t)$$');
legend('$$u_1$$','$$u_2$$','$$u_3$$','$$u_4$$');

figure(9041003);
plot(t,y(3,:),t,r(3,1:k));
grid on;
xlabel('$$t [s]$$');
legend('$$pz$$','$$ref pz$$');

figure(9041004);
plot(t,y(9,:),t,r(9,1:k));
grid on;
xlabel('$$t [s]$$');
legend('$$vz$$','$$ref vz$$');

figure(9041005);
plot(t,y(12,:),t,r(12,1:k));
grid on;
xlabel('$$t [s]$$');
legend('$$wz$$','$$ref wz$$');


figure(9041006);
plot(t,y(4:5,:),t,r(4:5,1:k));
grid on;
xlabel('$$t [s]$$');
legend('$$fi$$','$$theta$$','$$ref fi$$', '$$ref theta$$');

figure(9041007);
plot(t,y(1:2,:),t,r(1:2,1:k));
grid on;
xlabel('$$t [s]$$');
legend('$$px$$','$$py$$','$$ref px$$', '$$ref py$$');



