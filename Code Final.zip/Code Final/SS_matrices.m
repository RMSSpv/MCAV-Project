function [A, B, C, D] = SS_matrices(m, Jx, Jy, Jz, beta, g, ang, fi, theta, psi, vx, vy, vz, wx, wy, wz, r1x, r1y, r1z, r2x, r2y, r2z, r3x, r3y, r3z, r4x, r4y, r4z)


A1 = zeros (3,3) ;

A2 = [ vy*(cos(fi)*sin(theta)*cos(psi)+sin(fi)*sin(psi))+vz*(-sin(fi)*sin(theta)*cos(psi)+cos(fi)*sin(psi)) , vx*(-sin(theta)*cos(psi))+vy*(sin(fi)*cos(theta)*cos(psi))+vz*(cos(fi)*cos(theta)*cos(psi)) , vx*(-cos(theta)*sin(psi))+vy*(-sin(fi)*sin(theta)*sin(psi)-cos(fi)*cos(psi))+vz*(-cos(fi)*sin(theta)*sin(psi)+sin(fi)*cos(psi)) ;
       vy*(cos(fi)*sin(theta)*sin(psi)-sin(fi)*cos(psi))+vz*(-sin(fi)*sin(theta)*sin(psi)-cos(fi)*cos(psi)) , vx*(-sin(theta)*sin(psi))+vy*(sin(fi)*cos(theta)*sin(psi))+vz*(cos(fi)*cos(theta)*sin(psi)) , vx*(cos(theta)*cos(psi))+vy*(sin(fi)*sin(theta)*cos(psi)-cos(fi)*sin(psi))+vz*(cos(fi)*sin(theta)*cos(psi)+sin(fi)*sin(psi)) ;
       cos(theta)*(vy*cos(fi)-vz*sin(fi))                                                                   , -(vx*cos(theta)+vy*(sin(fi)*sin(theta))+vz*(cos(fi)*sin(theta)))                              , 0 ] ;

A3 = [ cos(theta)*cos(psi) , sin(fi)*sin(theta)*cos(psi)-cos(fi)*sin(psi) , cos(fi)*sin(theta)*cos(psi)+sin(fi)*sin(psi) ;
       cos(theta)*sin(psi) , sin(fi)*sin(theta)*sin(psi)+cos(fi)*cos(psi) , cos(fi)*sin(theta)*sin(psi)-sin(fi)*cos(psi) ;
       -sin(theta)         , sin(fi)*cos(theta)                           , cos(fi)*cos(theta) ] ;

A4 = zeros (3,3) ;

A5 =  zeros (3,3) ;

A6 = [wy*tan(theta)*cos(fi) - wz*tan(theta)*sin(fi) , wy*sin(fi)* (sec (theta))^2 + wz*cos(fi)*(sec (theta))^2 , 0 ;
      -wy*sin(fi)-wz*cos(fi) , 0 , 0 ;
      1/cos(fi)*(wy*cos(fi)-wz*sin(fi)) , ((1/cos(theta))^2)*sin(theta)*(wy*sin(fi)+wz*cos(fi)), 0 ] ;

A7 = zeros (3,3) ;

A8 = [ 1 , sin(theta)*tan(fi) , cos(theta)*tan(fi) ;
       0 , cos(theta) , -sin(fi) ;
       0 , sin(theta)/cos(fi) , cos(theta)/cos(fi) ] ;

A9 = zeros (3,3) ;

A10 = [0 , -cos(fi)*g, 0;
       cos(theta)*cos(fi)*g, -sin(fi)*sin(theta)*g, 0;
       -sin(theta)*cos(fi)*g, -sin(fi)*cos(theta)*g, 0];

A11 = [- (beta(1)*(vx^2 + vy^2 + vz^2)^(1/2))/m - (beta(1)*vx^2)/(m*(vx^2 + vy^2 + vz^2)^(1/2)), wz, -wy;
       -wz,- (beta(5)*(vx^2 + vy^2 + vz^2)^(1/2))/m - (beta(5)*vy^2)/(m*(vx^2 + vy^2 + vz^2)^(1/2)), wx;
       wy, -wx, - (beta(9)*(vx^2 + vy^2 + vz^2)^(1/2))/m - (beta(9)*vz^2)/(m*(vx^2 + vy^2 + vz^2)^(1/2))];

A12 = [0, -vz, vy;
       vz, 0, -vx;
       -vy, vx, 0];


A13 = zeros(3,3);

A14 = zeros(3,3);

A15 = zeros(3,3);

A16 = [0, wz*(Jy-Jz)*(1/Jx), wy*(Jy-Jz)*(1/Jx);
wz*(Jz-Jx)*(1/Jy), 0, wx*(Jz-Jx)*(1/Jy);
wy*(Jx-Jy)*(1/Jz), wx*(Jx-Jy)*(1/Jz), 0] ;

A = [A1 , A2 , A3 , A4 ;
     A5 , A6 , A7 , A8 ;
     A9 , A10 , A11 , A12 ;
     A13 , A14 , A15 , A16 ];

B1 = zeros (3,1) ;

B2 = zeros (3,1) ;

B3 = zeros (3,1) ;

B4 = zeros (3,1) ;

B5 =  zeros (3,1) ;

B6 =  zeros (3,1) ;

B7 =  zeros (3,1) ;

B8 =  zeros (3,1) ;

B9 = 1/m*[0 ; -sin(ang) ; -cos(ang)] ;

B10 = 1/m*[0 ; sin(ang) ; -cos(ang)] ;

B11 = 1/m*[0 ; sin(ang) ; -cos(ang)] ;

B12 = 1/m*[0 ; -sin(ang) ; -cos(ang)] ;

B13 = [-(1/Jx)*(r1z*sin(ang)*(-1)+r1y*cos(ang)) ; (1/Jy) * (r1x*cos(ang)) ; (1/Jz) * (r2x*sin(ang)*(-1)) ] ;

B14 = [-(1/Jx)*(r2z*sin(ang)+r2y*cos(ang)) ; (1/Jy) * (r2x*cos(ang)) ; (1/Jz) * (r2x*sin(ang)) ] ;

B15 = [-(1/Jx)*(r3z*sin(ang)+r3y*cos(ang)) ; (1/Jy) * (r3x*cos(ang)) ; (1/Jz) * (r3x*sin(ang)) ] ;

B16 =[-(1/Jx)*(r4z*sin(ang)*(-1)+r4y*cos(ang)) ; (1/Jy) * (r4x*cos(ang)) ; (1/Jz) * (r4x*sin(ang)*(-1)) ] ;

B = [B1 , B2 , B3 , B4 ;
     B5 , B6 , B7 , B8 ;
     B9 , B10 , B11 , B12 ;
     B13 , B14 , B15 , B16 ] ;

%C = [eye(3), zeros(3,9); zeros(1,5),1, zeros(1,6)];
C=eye(12);

D = zeros(12,4);
%D = zeros(4,4);

end