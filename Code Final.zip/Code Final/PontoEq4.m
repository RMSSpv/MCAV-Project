g = (393/1025)*9.8;
mL=360*(1025/170); %360kg é a masssa do Lander de outra missão e 170kg do Rover, decidi manter a proporção
mR=1025;
m=mR+mL;


Cd=1.05;
rho = 0.015;
A=diag([6*1.08; 1.08*1.56;6*1.56]);
beta = Cd*rho*A/2;


syms vx vy T ;

vB=(Euler2R([-pi/180;pi/180;0]))'*[vx;vy;0];
normVB=(mtimes(vB(1),vB(1))+mtimes(vB(2),vB(2))+mtimes(vB(3),vB(3)))^0.5;
Fd=-beta*(normVB^2)*(vB/normVB);


eqn1 = skew(r1)*T*[0;-sin(ang); -cos(ang)] + skew(r2)*T*[0;sin(ang); -cos(ang)] + skew(r4)*T*[0;-sin(ang); -cos(ang)] + skew(r3)*T*[0;sin(ang); -cos(ang)]== [0;0;0];
eqn2 = m*g*(Euler2R([-pi/180;pi/180;0]))'*[0; 0; 1] + Fd + T*[0;-sin(ang); -cos(ang)]+T*[0;sin(ang); -cos(ang)]+T*[0;sin(ang); -cos(ang)]+T*[0;-sin(ang); -cos(ang)]== [0;0;0];


eq1=vpa(eqn1)
eq2=vpa(eqn2)
fd=vpa(Fd)

[E1] = equationsToMatrix([eqn1], [vx , vy , T]);


X = linsolve(E1(1),E1(2),E1(3));
Ueq=vpa([X(3);X(4);X(5);X(6)])
Veq=vpa((Euler2R([-pi/180;pi/180;0]))'*[X(1)^0.5;X(2)^0.5;0])

