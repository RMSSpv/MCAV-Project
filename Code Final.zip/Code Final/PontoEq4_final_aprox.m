
g = (393/1025)*9.8;
mL=360*(1025/170); %360kg é a masssa do Lander de outra missão e 170kg do Rover, decidi manter a proporção
mR=1025;
%m=mR+mL; %Com Rover
m=mL; %Sem Rover

CML=[1.35; 3; -2.74];
CMR=[1.35; 3; -1.1];
%CM = (mL*CML+mR*CMR)*(1/m);%Com Rover
CM=CML;%Sem Rover

%posições relativas dos retro rockets em relação ao centro de massa do body
dif = (2.7-1.56)/2;
r1=[2.7-dif;6;-2.2]-CM;
r2=[dif;0;-2.2]-CM;
r3=[2.7-dif;0;-2.2]-CM;
r4=[dif;6;-2.2]-CM;


Cd=1.05;
rho = 0.015;
%A=diag([13.08; 7.62;12.84]);%Com Rover
A=diag([13.08; 7.62;12.84]);%Sem Rover
%depois por valor das areas bem
beta = Cd*rho*A/2;

ang = 20*pi/180 ;
theta = +pi/(180*8); %o theta na realidade é o phi
fi = -theta; % o phi na realidade é o theta
psi=0;
syms vx vy T1 T2 T3 T4 ;
eqn1 = skew(r1)*T1*[0;-sin(ang); -cos(ang)] + skew(r2)*T2*[0;sin(ang); -cos(ang)] + skew(r3)*T3*[0;sin(ang); -cos(ang)] + skew(r4)*T4*[0;-sin(ang); -cos(ang)]== [0;0;0];
eqn2 = m*g*(Euler2R([theta;fi;psi]))'*[0; 0; 1] - beta*((Euler2R([theta;fi;psi]))'*[vx;vy;0]) + T1*[0;-sin(ang); -cos(ang)]+T2*[0;sin(ang); -cos(ang)]+T3*[0;sin(ang); -cos(ang)]+T4*[0;-sin(ang); -cos(ang)]== [0;0;0];
[E1,E2] = equationsToMatrix([eqn1, eqn2], [vx , vy , T1, T2, T3, T4]);
X = linsolve(E1,E2);

Ueq=vpa([X(3);X(4);X(5);X(6)])
Veq=vpa((Euler2R([-pi/180;pi/180;0]))'*[X(1)^0.5;X(2)^0.5;0])


%usando a formula em questão da um erro mas vamos desprezar (teria-se de
%fazer interseção de planos), visto que vx e vy são relativamente
%semelhantes pelo que o erro na direçção do drag não é assim tão
%consideravel

