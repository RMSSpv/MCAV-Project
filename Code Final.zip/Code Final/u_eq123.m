function u = u_eq123(vz, ang, m, g, beta, t)

%Acho que isto não vai intressar depois para achar o espaço de estado em
%cada ponto de eq
T1 = (((-beta(9)*vz^2)+m*g)/4)/cos(ang);
T2 = T1;
T3 = T1;
T4 = T1;
T1u = (t>=0)*T1;
T2u = (t>=0)*T2;
T3u = (t>=0)*T3;
T4u = (t>=0)*T4;
u=[T1u;T2u;T3u;T4u];

end