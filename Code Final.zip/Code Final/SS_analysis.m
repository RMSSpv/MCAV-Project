function Gl = SS_analysis(A_1, B_1, C_1, D_1, u, t, x0, n)
sys = ss(A_1,B_1,C_1,D_1);
[Vj,Jor] = jordan(A_1)
[V,DL,W] = eig(A_1)
mode_obs = C_1*V
mode_ctrl = W'*B_1
rank(mode_obs)
rank(mode_ctrl)
Gl=tf(sys);

y_L = lsim(sys,u,t,x0);
figure(10*n+1)
plot(t,u)
legend('T1','T2','T3', 'T4');

figure(10*n+2)
plot(t,y_L(:,1:3))
legend('px','py','pz');

figure(10*n+3)
plot(t,y_L(:,4:6))
legend('fi','theta','psi');

figure(10*n+4)
plot(t,y_L(:,7:9))
legend('vx','vy','vz');

figure(10*n+5)
plot(t,y_L(:,10:12))
legend('wx','wy','wz');

end