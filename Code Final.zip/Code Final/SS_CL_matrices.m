function [Kinf,CLinf,gammainf,info_inf, P] = SS_CL_matrices(A_1, B_1, C_1, D_1, Q, R, Gl)

A0 = A_1;
B1 = zeros(12,12); % estou a considerar w = r apenas
B2= B_1;
% z = [W1*x;W2*u] = [W1;0]*x + [0;W2]*u % Similar performance output to that of LQR (static weights)
W1 = sqrt(Q);
W2 = sqrt(R);
C1 = [W1];
C2 = -C_1;
D11 = zeros(12,12);  D12 = [zeros(8,4);W2];
D21 = eye(12);  D22 = D_1;

% v = r - x = -eye(3)*x + eye(3)*r = C2*x + D21*w + 0*u


B0 = [ B1 B2 ];
C0 = [ C1
       C2 ];
D0 = [D11 D12
      D21 D22];
P = ss(A0,B0,C0,D0);

nmeas = 12;
ncont = 4;
[Kinf,CLinf,gammainf,info_inf] = hinfsyn(P,nmeas,ncont);

%CL = lft(P1,K);
figure(904802);
sigma(Gl,Kinf,CLinf);
grid on;
legend('G','K','CL');

end