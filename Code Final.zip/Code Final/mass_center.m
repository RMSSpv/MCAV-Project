function CM = mass_center(mL, CML, mR, CMR, m)

CM = (mL*CML+mR*CMR)*(1/m);

end
