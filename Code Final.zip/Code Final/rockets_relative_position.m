function [r1x,r1y,r1z,r2x,r2y,r2z,r3x,r3y,r3z,r4x,r4y,r4z]=rockets_relative_position(CM)


%posições relativas dos retro rockets em relação ao centro de massa do body
r1=[(2.7+1.56)/2;6;-2.2]-CM;
r2=[(2.7-1.56)/2;0;-2.2]-CM;
r3=[(2.7+1.56)/2;0;-2.2]-CM;
r4=[(2.7-1.56)/2;6;-2.2]-CM;

%usado para a matriz B por conta do torque aplicado por cada um dos rockets

r1x = r1(1);
r1y = r1(2);
r1z = r1(3);
r2x = r2(1);
r2y = r2(2);
r2z = r2(3);
r3x = r3(1);
r3y = r3(2);
r3z = r3(3);
r4x = r4(1);
r4y = r4(2);
r4z = r4(3);
end